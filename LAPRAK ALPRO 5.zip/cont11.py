a=int(input("masukkan bilangan1: "))
b=int(input("masukkan bilangan2: "))

kali=a*b
print(kali)

