def sapa(nama):
    print  ("halo,", nama)
    return sapa

sapa("alice")
sapa(nama="alisa")