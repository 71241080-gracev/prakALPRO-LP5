celciustoF=lambda C:(9/5)*C+32
print("F =", (int(celciustoF(100))))
print("F =", (int(celciustoF(0))))
celciustoR=lambda C:0.8*C
print("R =", (int(celciustoR(80))))

celcius=float(input("masukakan suhu dalam celcius: "))
print("F =", (int(celciustoF(celcius))))
print("R =", (int(celciustoR(celcius))))