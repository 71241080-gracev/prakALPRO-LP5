def pesan(message):
    print(message)
    print(message)
    
print(pesan("halo!"))
