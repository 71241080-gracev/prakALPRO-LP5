def cek_angka():
    a=int(input("Masukkan bilangan1: "))
    b=int(input("Masukkan bilangan2: "))
    c=int(input("Masukkan bilangan3: "))
    if a!=b and b!=c and a!=c:
        if a+b==c or a+c==b or b+c==a:
            return "True"
        else:
            return "False"
    else:
            return "False"
hasil=cek_angka()
print(hasil)