digit_kiri=lambda b:b//10
print(digit_kiri(24))
print(digit_kiri(96))
