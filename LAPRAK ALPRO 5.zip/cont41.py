def digit_kiri(b):
    return b//10
print(digit_kiri(24))
print(digit_kiri(96))
