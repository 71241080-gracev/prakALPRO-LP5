def cek_digit_kanan():
    a=int(input("Masukkan bilangan1: "))
    b=int(input("Masukkan bilangan2: "))
    c=int(input("Masukkan bilangan3: "))
    if a%10==b%10 or a%10==c%10 or b%10==c%10:
        return "True"
    else:
        return "False"
hasil=cek_digit_kanan()
print(hasil)