def besarmana(f, h):
    if f>h:
        return f
    else:
        return h
print(besarmana(0, 900))
