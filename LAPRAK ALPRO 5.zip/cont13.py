def kali(a, b):
    return a*b
print(kali(10, 12))
