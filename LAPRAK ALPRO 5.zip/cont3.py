def total(belanja, diskon=0):
    bayar=belanja-(belanja*diskon)/100
    return bayar

print (total(200000))
print (total(1000000, 50))
