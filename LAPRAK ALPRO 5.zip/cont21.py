def kurang(x, y):
    return x-y
print(kurang(50, 34))
