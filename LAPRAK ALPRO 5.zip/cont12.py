hasil=pembagian
print(hasil(12))

def pembagian(a):
    return a/2
